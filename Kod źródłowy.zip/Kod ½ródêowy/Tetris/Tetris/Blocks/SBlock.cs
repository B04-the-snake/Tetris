﻿namespace Tetris
{
    /* Kod definiuje klasę SBlock, która dziedziczy po klasie Block i 
     * reprezentuje blok typu S w grze Tetris. */

    public class SBlock : Block
    {
        public override int Id => 5;

        protected override Position StartOffset => new(0, 3);

        protected override Position[][] Tiles => new Position[][] 
        {
            new Position[] { new(0,1), new(0,2), new(1,0), new(1,1) },
            new Position[] { new(0,1), new(1,1), new(1,2), new(2,2) },
            new Position[] { new(1,1), new(1,2), new(2,0), new(2,1) },
            new Position[] { new(0,0), new(1,0), new(1,1), new(2,1) }
        };
    }

    /* W przypadku bloku typu S, tablica  Tiles zawiera 
     * 4 tablice pozycji reprezentujące klocki składowe 
     * dla każdego z możliwych obrotów. 
     * 
     * Pozycje te są zdefiniowane w taki sposób, 
     * aby klocki składowe tworzyły literę "S". 
     * 
     * Kolejne pozycje definiują pozycję klocków składowych bloku 
     * dla kolejnych obrotów, zgodnie z ruchem wskazówek zegara. */

}