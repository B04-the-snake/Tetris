﻿namespace Tetris
{
    /* Klasa  TBlock dziedziczy po klasie Block i reprezentuje blok 
     * w kształcie litery T w grze Tetris. 
     * 
     * Klasa ta definiuje cztery pozycje klocka w zależności od jego obrotu 
     * oraz punkt startowy dla pojawienia się klocka na planszy. 
     * 
     * Wszystkie te informacje są zdefiniowane poprzez implementację 
     * metod abstrakcyjnych klasy Block. Klasa TBlock zawiera również 
     * publiczne pole Id, które reprezentuje identyfikator klocka w grze. */

    public class TBlock : Block
    {
        public override int Id => 6;

        protected override Position StartOffset => new(0, 3);

        protected override Position[][] Tiles => new Position[][] 
        {
            new Position[] {new(0,1), new(1,0), new(1,1), new(1,2)},
            new Position[] {new(0,1), new(1,1), new(1,2), new(2,1)},
            new Position[] {new(1,0), new(1,1), new(1,2), new(2,1)},
            new Position[] {new(0,1), new(1,0), new(1,1), new(2,1)}
        };
    }
}
