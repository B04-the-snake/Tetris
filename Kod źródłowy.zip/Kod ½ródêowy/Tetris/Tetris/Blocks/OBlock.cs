﻿namespace Tetris
{
    /* W klasie  OBlock zdefiniowana jest tablica dwuwymiarowa tiles, 
     * która zawiera pozycje klocków tworzących blok typu O 
     * w czterech możliwych obrotach. Klasa implementuje właściwości 
     * Id, StartOffset oraz Tiles, które nadpisują te same właściwości 
     * z klasy bazowej Block. 
     * 
     * Właściwość Id zwraca identyfikator bloku, 
     * StartOffset definiuje początkowe położenie bloku na planszy, 
     * a właściwość Tiles zawiera informacje o pozycjach klocków 
     * w kolejnych obrotach bloku. */

    public class OBlock : Block
    {
        private readonly Position[][] tiles = new Position[][]
        {
            new Position[] { new(0,0), new(0,1), new(1,0), new(1,1) }
        };

        public override int Id => 4;
        protected override Position StartOffset => new(0, 4);
        protected override Position[][] Tiles => tiles;
    }  
}
