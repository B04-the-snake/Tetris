﻿namespace Tetris
{
    /* Klasa LBlock reprezentuje blok typu L w grze Tetris. 
     * Dziedziczy po klasie Block i nadpisuje jej właściwości 
     * Id, StartOffset i Tiles, aby określić unikalne cechy dla 
     * tego konkretnego bloku. Id ustawione jest na 3, a StartOffset 
     * określa początkowe położenie bloku. 
     * Tiles zawiera tablicę tablic pozycji, które reprezentują kształt bloku
     * w każdym z jego czterech możliwych obrotów. */
    public class LBlock : Block
    {
        public override int Id => 3;

        protected override Position StartOffset => new(0, 3);

        protected override Position[][] Tiles => new Position[][] 
        {
            new Position[] {new(0,2), new(1,0), new(1,1), new(1,2)},
            new Position[] {new(0,1), new(1,1), new(2,1), new(2,2)},
            new Position[] {new(1,0), new(1,1), new(1,2), new(2,0)},
            new Position[] {new(0,0), new(0,1), new(1,1), new(2,1)}
        };
    }
}