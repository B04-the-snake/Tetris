﻿namespace Tetris
{
    /* Ten kod to implementacja klasy JBlock dziedziczącej po klasie Block. 
     * JBlock reprezentuje jeden z bloków w grze Tetris, który składa się z 
     * 4 kwadratowych klocków (tzw. "tiles"), 
     * tworzących kształt litery "J". */

    public class JBlock : Block
    {
        public override int Id => 2;

        protected override Position StartOffset => new(0, 3);

        /* Kształt bloku jest opisany za pomocą macierzy dwuwymiarowej Tiles, 
         * gdzie każda z czterech rotacji bloku składa się z czterech pozycji 
         * z klasy Position reprezentujących współrzędne (wiersz i kolumna) 
         * każdego z klocków. */

        protected override Position[][] Tiles => new Position[][] 
        {
            new Position[] {new(0, 0), new(1, 0), new(1, 1), new(1, 2)},
            new Position[] {new(0, 1), new(0, 2), new(1, 1), new(2, 1)},
            new Position[] {new(1, 0), new(1, 1), new(1, 2), new(2, 2)},
            new Position[] {new(0, 1), new(1, 1), new(2, 1), new(2, 0)}
        };
    }
}

