﻿using System.Collections.Generic;

namespace Tetris
{
    public abstract class Block
    {
        // Właściwość  Tiles reprezentuje układ klocków w różnych stanach rotacji. 
        protected abstract Position[][] Tiles { get; }

        // Właściwość StartOffset określa pozycję początkową bloku. 
        protected abstract Position StartOffset { get; }

        // Właściwość Id zwraca identyfikator bloku. 
        public abstract int Id { get; }

        
        private int rotationState;
        private readonly Position offset;

        protected Block() 
        {
            offset = new Position(StartOffset.Row, StartOffset.Column);
        }

        /* Metoda TilePositions() zwraca pozycje wszystkich klocków 
         * w obecnym stanie rotacji i położeniu bloku. */

        public IEnumerable<Position> TilePositions()
        {
            foreach (Position p in Tiles[rotationState]) 
            {
                yield return new Position(p.Row + offset.Row, p.Column + offset.Column);
            }
        }
        
        // Metoda  RotateCW() obraca blok zgodnie z ruchem wskazówek zegara.
        public void RotateCW()
        {
            rotationState = (rotationState + 1) % Tiles.Length;
        }

        // Metoda  RotateCCW() obraca blok przeciwnie do ruchu wskazówek zegara. 
        public void RotateCCW()
        {
            if (rotationState == 0)
            {
                rotationState = Tiles.Length - 1;
            }
            else
            {
                rotationState--;
            }
        }

        // Metoda Move() przesuwa blok o określoną liczbę wierszy i kolumn.
        public void Move(int rows, int columns)
        {
            offset.Row += rows;
            offset.Column += columns;
        }

        // Metoda Reset() przywraca początkowy stan bloku.
        public void Reset()
        {
            rotationState = 0;
            offset.Row = StartOffset.Row;
            offset.Column = StartOffset.Column;
        }
    }
}
