﻿using System;

namespace Tetris
{
    public class BlockQueue
    {
        private readonly Block[] blocks = new Block[]
        {
            new IBlock(),
            new JBlock(),
            new LBlock(),
            new OBlock(),
            new SBlock(),
            new TBlock(),
            new ZBlock()
        };

        private readonly Random random = new();

        /* NextBlock jest właściwością tylko do odczytu (get), 
         * która przechowuje blok, który jest następny w kolejce 
         * do wygenerowania. Jest zainicjowany wartością losowego 
         * bloku podczas tworzenia instancji klasy BlockQueue. */

        public Block NextBlock { get; private set; }

        /* Konstruktor inicjalizuje nową instancję klasy BlockQueue. 
         * Ustawia wartość pola NextBlock na losowy blok wygenerowany 
         * przez funkcję RandomBlock. */

        public BlockQueue()
        {
            NextBlock = RandomBlock();
        }

        /* Funkcja zwraca losowy blok z listy bloków 
         * zdefiniowanych w tablicy "blocks" w klasie BlockQueue. 
         * Funkcja korzysta z obiektu klasy Random, 
         * aby wygenerować losowy indeks 
         * z zakresu 0 do długości tablicy bloków. */

        private Block RandomBlock()
        {
            return blocks[random.Next(blocks.Length)];
        }

        /* Metoda pobiera aktualny blok zapisany w polu NextBlock i 
         * zwraca jego wartość, a następnie wywołuje funkcję RandomBlock, 
         * aby wygenerować nowy blok do ustawienia jako NextBlock. 
         * 
         * Następnie sprawdza, czy nowy blok jest różny od poprzedniego bloku, 
         * aby uniknąć generowania dwóch bloków o tym samym typie z rzędu. */

        public Block GetAndUpdate()
        {
            Block block = NextBlock;

            do
            {
                NextBlock = RandomBlock();
            }
            while (block.Id == NextBlock.Id);

            return block;
        }
    }
}