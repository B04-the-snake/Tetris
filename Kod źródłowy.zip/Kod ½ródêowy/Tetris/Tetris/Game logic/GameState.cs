﻿#nullable disable
namespace Tetris
{
    /* Konstruktor klasy GameState, inicjujący grę poprzez utworzenie planszy,
       kolejki bloków i ustawienie początkowego bloku. */
    public class GameState
    {
        private Block currentBlock;
        public Block CurrentBlock 
        {
            get => currentBlock;
            private set 
            {
                currentBlock = value;
                currentBlock.Reset();

                for (int i = 0; i < 2; i++)
                {
                    currentBlock.Move(1, 0);

                    if (!BlockFits()) 
                    {
                        currentBlock.Move(-1, 0);
                    }

                }
            }
        }

        public GameGrid GameGrid { get; }
        public BlockQueue BlockQueue { get; }
        public bool GameOver { get; private set; }
        public int Score { get; private set; }
        public Block HeldBlock { get; private set; }
        public bool CanHold { get; private set; }

        public GameState()
        {
            GameGrid = new GameGrid(22, 10);
            BlockQueue = new BlockQueue();
            CurrentBlock = BlockQueue.GetAndUpdate();
            CanHold = true;
        }

        /*  Metoda prywatna, sprawdzająca, czy obecny blok może 
         *  zmieścić się na planszy, zwracająca wartość logiczną. */
        private bool BlockFits()
        {
            foreach (Position p in CurrentBlock.TilePositions())
            {
                if (!GameGrid.IsEmpty(p.Row, p.Column))
                {
                    return false;
                }
            }
            return true;
        }

        /* Metoda, pozwalająca na wymianę obecnego bloku 
         * z przechowywanym blokiem (jeśli jest) i ustawiająca
         * blok przechowywany jako obecny. */

        public void HoldBlock()
        {
            if (!CanHold)
            {
                return;
            }

            if (HeldBlock == null)
            {
                HeldBlock = CurrentBlock;
                CurrentBlock = BlockQueue.GetAndUpdate();
            }
            else
            {
                (HeldBlock, CurrentBlock) = (CurrentBlock, HeldBlock);
            }

            CanHold = false;
        }

        // Metoda obracająca obecny blok o 90 stopni w prawo

        public void RotateBlockCW()
        {
            CurrentBlock.RotateCW();
            if (!BlockFits())
            {
                CurrentBlock.RotateCCW();
            }
        }

        // Metoda obracająca obecny blok o 90 stopni w lewo, jeśli jest to możliwe.

        public void RotateBlockCCW()
        {
            CurrentBlock.RotateCCW();

            if (!BlockFits())
            {
                CurrentBlock.RotateCW();
            }
        }

        // Metoda przesuwająca obecny blok o jedną pozycję w lewo, jeśli jest to możliwe.
        public void MoveBlockLeft()
        {
            CurrentBlock.Move(0, -1);

            if (!BlockFits())
            {
                CurrentBlock.Move(0, 1);
            }
        }

        // Metoda przesuwająca obecny blok o jedną pozycję w prawo, jeśli jest to możliwe.

        public void MoveBlockRight()
        {
            CurrentBlock.Move(0, 1);

            if (!BlockFits())
            {
                CurrentBlock.Move(0, -1);
            }
        }

        /* Metoda prywatna, sprawdzająca, czy gra się skończyła
         * (czy istnieją bloki w pierwszych dwóch wierszach planszy),
         * zwracająca wartość logiczną. */

        private bool IsGameOver()
        {
            return !(GameGrid.IsRowEmpty(0) && GameGrid.IsRowEmpty(1));
        }

        /* Metoda ustawiająca obecny blok na planszy i sprawdzająca, 
         * czy należy usunąć pełne rzędy, zwiększająca wynik gracza i 
         * ustawiająca kolejny blok lub kończąca grę, 
         * jeśli nie ma już możliwości ustawienia bloku na planszy. */

        private void PlaceBlock()
        {
            foreach (Position p in CurrentBlock.TilePositions())
            {
                GameGrid[p.Row, p.Column] = CurrentBlock.Id;
            }

            Score += GameGrid.ClearFullRows();

            if (IsGameOver())
            {
                GameOver = true;
            }
            else
            {
                CurrentBlock = BlockQueue.GetAndUpdate();
                CanHold = true;
            }
        }

        /* Metoda przesuwająca obecny blok o jedną pozycję w dół, 
         * jeśli jest to możliwe, lub umieszczająca blok na planszy i 
         * ustawiająca kolejny blok, jeśli nie można go już przesunąć w dół. */

        public void MoveBlockDown()
        {
            CurrentBlock.Move(1, 0);

            if (!BlockFits())
            {
                CurrentBlock.Move(-1, 0);
                PlaceBlock();
            }   
        }

        /* Metoda prywatna, obliczająca odległość, na jaką można opuścić 
         * pojedynczy klocek, zwracając wynik jako liczbę całkowitą. */

        private int TileDropDistance(Position p)
        {
            int drop = 0;

            while (GameGrid.IsEmpty(p.Row + drop + 1, p.Column))
            {
                drop++;
            }

            return drop;
        }

        /* Metoda obliczająca odległość, 
         * na jaką można opuścić cały blok, 
         * zwracając wynik jako liczbę całkowitą. */

        public int BlockDropDistance()
        {
            int drop = GameGrid.Rows;

            foreach (Position p in CurrentBlock.TilePositions())
            {
                drop = System.Math.Min(drop, TileDropDistance(p));
            }

            return drop;
        }

        /* Metoda opuszczająca obecny blok na maksymalną możliwą odległość i 
         * umieszczająca go na planszy, następnie sprawdzająca, 
         * czy należy usunąć pełne rzędy i ustawiająca kolejny blok lub 
         * kończąca grę, jeśli nie ma już możliwości ustawienia bloku na planszy. */

        public void DropBlock()
        {
            CurrentBlock.Move(BlockDropDistance(), 0);
            PlaceBlock();
        }
    }
}
