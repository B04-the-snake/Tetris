﻿namespace Tetris
{
    /* Klasa Position zawiera jedynie dwa właściwości: 
     * Row i Column, które przechowują pozycję rzędu i 
     * kolumny dla obiektu Position. 
     * Konstruktor klasy inicjuje te właściwości wartościami 
     * podanymi jako argumenty. */

    public class Position
    {
        // Klasa nie posiada żadnych funkcji, jedynie deklaruje konstruktor.
        public int Row { get; set; }
        public int Column { get; set; }

        public Position(int row, int column)
        {
            Row = row;
            Column = column;
        }
    }
}
