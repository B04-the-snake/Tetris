﻿namespace Tetris
{
    public class GameGrid
    {
        /* Deklaracja prywatnego pola siatki grid oraz 
         * właściwości Rows i Columns, które są publiczne 
         * i tylko do odczytu. */

        private readonly int[,] grid;
        public int Rows { get; }
        public int Columns { get; }

        /* Operator [] dla klasy GameGrid, 
         * umożliwia dostęp do elementów siatki 
         * za pomocą indeksów wiersza i kolumny 
         
         Właściwość get zwraca wartość elementu siatki, 
         a wartość set przypisuje nową wartość do elementu siatki. */

        public int this[int r, int c] 
        { 
            get => grid[r, c];
            set => grid[r, c] = value;
        }

        /* Konstruktor dla klasy GameGrid, 
         * który tworzy nową siatkę o podanych rozmiarach i 
         * ustawia wszystkie jej elementy na wartość zero. */
        public GameGrid(int rows, int columns)
        {
            Rows = rows;
            Columns = columns;
            grid = new int[rows, columns];
        }

        /* Metoda IsInside, zwraca true, 
         * jeśli podane indeksy wiersza i kolumny są w granicach
         * siatki, a w przeciwnym razie false */

        public bool IsInside(int r, int c)
        {
            return r >= 0 && r < Rows && c >= 0 && c < Columns;
        }

        /* Metoda IsEmpty, zwraca true, jeśli podany element siatki jest pusty i 
         * znajduje się w granicach siatki, w przeciwnym wypadku false */

        public bool IsEmpty(int r, int c)
        {
            return IsInside(r, c) && grid[r, c] == 0;
        }

        /* Metoda IsRowFull, zwraca true, jeśli dany wiersz siatki jest pełny, 
         * tzn. że każdy element w tym wierszu ma wartość różną od zera, 
         * a w przeciwnym wypadku false */
        public bool IsRowFull(int r)
        {
            for (int c = 0; c < Columns; c++)
            {
                if (grid[r, c] == 0)
                {
                    return false;
                }
            }
            return true;
        }
        
        /* Metoda IsRowEmpty, zwraca true, jeśli dany wiersz siatki jest pusty, 
         * tzn. że każdy element w tym wierszu ma wartość równą zero, 
         * a w przeciwnym razie false */

        public bool IsRowEmpty(int r) 
        { 
            for (int c = 0; c < Columns; c++)
            {
                if (grid[r, c] != 0)
                {
                    return false;
                }
            }
            return true;
        }

        /* Funkcja ClearRow, ustawia wartość 0 dla każdego elementu w podanym rzędzie 'r'. */

        private void ClearRow(int r)
        {
            for (int c = 0; c < Columns; c++)
            {
                grid[r, c] = 0;
            }
        }

        /* Funkcja MoveRowDown, przesuwa rzędy w dół o określoną liczbę numOfRows i
         * ustawia wartość 0 dla każdego elementu w rzędzie początkowym 'r'. */

        private void MoveRowDown(int r, int numOfRows)
        {
            for (int c = 0; c < numOfRows; c++)
            {
                grid[r + numOfRows, c] = grid[r, c];
                grid[r, c] = 0;
            }
        }

        /* Funkcja ClearFullRows, usuwa pełne rzędy w siatce Tetrisa. 
         * Jeśli pełny rząd zostanie usunięty, to ClearRow jest wywoływana, aby wyczyścić dany rząd. 
         * Następnie MoveRowDown jest wywoływana, 
         * aby przesunąć wszystkie wiersze powyżej usuniętego wiersza w dół o odpowiednią liczbę wierszy, 
         * jeśli to konieczne. 
         * Funkcja zwraca liczbę usuniętych rzędów. */

        public int ClearFullRows()
        {
            int cleared = 0;

            for (int r = Rows-1; r >= 0; r--)
            {
                if (IsRowFull(r))
                {
                    ClearRow(r);
                    cleared++;
                }

                else if (cleared > 0)
                {
                    MoveRowDown(r, cleared);
                }
            }
            return cleared;
        }
    }
}
